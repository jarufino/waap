import Image from 'next/image';

export default function Home() {
  return (
    <div className="masthead">
      <div className="container">
          <h3>Bem vindos à Academia WAAP!</h3>
          <h2>Sua saúde, nossa meta</h2>       
      </div>
    </div>
  )
}
