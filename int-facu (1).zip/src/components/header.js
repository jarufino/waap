import { Navbar, NavbarBrand, Container, Nav } from "react-bootstrap";
import { useState, useEffect, useRef } from 'react';

import Image from 'next/image';

export default function Header() {
  const [ classe, setClasse ] = useState('');

  const listenScrollEvent = (event) => {
    if (window.scrollY < 73) {
      setClasse("")
    } else if (window.scrollY > 70) {
      setClasse("scrolled") 
    } 
  } 

  useEffect(() => {
    window.addEventListener('scroll', listenScrollEvent);
    return () =>
      window.removeEventListener('scroll', listenScrollEvent);
  }, []);

  const useOnClickOutside = (ref, handler) => {
    useEffect(() => {
      const listener = event => {
        if (!ref.current || ref.current.contains(event.target)) {
          return;
        }
        handler(event);
      };
      document.addEventListener('mousedown', listener);
  
      return () => {
        document.removeEventListener('mousedown', listener);
      };
    },
    [ref, handler],
    );
  };

  return (
    <Navbar expand="lg" fixed="top" className={classe}>
      <Container fluid>            
      <NavbarBrand href='/'><Image src="/logo-waap.png" width="70" height="70" alt="logo" /></NavbarBrand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto ms-auto text-uppercase py-4 py-lg-0">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="#contato">Contato</Nav.Link>           
              <Nav.Link href="#link">Área restrita</Nav.Link>           
            </Nav>
          </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
