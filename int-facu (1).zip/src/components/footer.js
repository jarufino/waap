import { Container, Row, Col } from "react-bootstrap";

export default function Footer() {
  return (
    <footer id="contato" className="py-4">
      <Container>
        <Row>
          <Col md={12} className="column">
              <h2>Nosso Contato:</h2>
              <p>email: contato@academiawapp.com.br</p>
              <p>Telefone: (11)1234-1234</p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

